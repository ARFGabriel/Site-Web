$('.nav-toggle').click(function(e){
    e.preventDefault();
    $('nav').toggleClass('is-open');
})